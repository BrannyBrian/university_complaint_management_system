
<div class="container-home">

	<div class="jumbotron jumbotron-main">
		<h1>Complain Type</h1>
	</div>
<div class="row"  style="margin-top:3em;">
	<div class="col-sm-4 col-sm-offset-1 col-md-2 col-md-offset-1 container-box">
		<a href="<?=base_url('complaintregister/1'); ?>">
			<img class="img-responsive " src="<?=base_url('assets/images/electrician.png'); ?>">
		</a>
	</div>
	<div class="col-sm-4 col-sm-offset-1 col-md-2 col-md-offset-2 container-box">
		<a href="<?=base_url('complaintregister/2'); ?>">
			<img class="img-responsive " src="<?=base_url('assets/images/civil.png'); ?>" >
		</a>
	</div>
	<div class="col-sm-4 col-sm-offset-1 col-md-2 col-md-offset-2 container-box">
		<a href="<?=base_url('complaintregister/4'); ?>">
			<img  class="img-responsive" src="<?=base_url('assets/images/carpenter.png'); ?>">
		</a>
	</div>

</div>
<div class="row" style="margin-top:3em;">
	<div class="col-sm-4 col-sm-offset-1 col-md-2 col-md-offset-1 container-box">
		<a href="<?=base_url('complaintregister/3'); ?>">
			<img class="img-responsive " src="<?=base_url('assets/images/plumb.jpg'); ?>">
		</a>
	</div>
	<div class="col-sm-4 col-sm-offset-1 col-md-2 col-md-offset-2 container-box">
		<a href="<?=base_url('complaintregister/5'); ?>">
			<img class="img-responsive " src="<?=base_url('assets/images/drainage.png'); ?>" >
		</a>
	</div>
</div>
</div>
