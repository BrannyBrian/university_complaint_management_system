</div>
<footer>
	<center><h2>Gujrat Vidyapith Ahmedabad</h2></center>

</footer>
</body>
</html>